﻿module AssemblyInfo

open System
open System.Reflection;
open System.Runtime.InteropServices;
 
[<assembly: AssemblyTitle("RPS.Domain")>]
[<assembly: AssemblyDescription("F# RPS Game")>]
[<assembly: AssemblyCompany("POkvist")>]
[<assembly: AssemblyProduct("RPS.Domain")>]
[<assembly: AssemblyVersion("0.1.0.*")>]
[<assembly: AssemblyFileVersion("0.1.0.*")>]
 
do()

