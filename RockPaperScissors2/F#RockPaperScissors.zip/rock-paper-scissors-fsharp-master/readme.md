#Rock-Paper-Scissors in Fsharp

A simple RPS domain in F#.
Code for the F# blog series;

- [Part 1 - Modeling an RPS Game](http://www.jayway.com/2014/01/13/exploring-f-through-modeling/)
- [Part 2 - Command handling](http://www.jayway.com/2014/02/24/exploring-f-through-modeling-2/)
- [Part 3 - Refactoring #1](http://www.jayway.com/2014/07/03/exploring-f-through-modeling-3/)
- Part 4 - C# infrastrcuture *Upcoming*




